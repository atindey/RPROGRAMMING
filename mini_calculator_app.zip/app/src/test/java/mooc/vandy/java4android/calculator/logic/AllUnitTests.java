package mooc.vandy.java4android.calculator.logic;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import io.magnum.autograder.junit.Rubric;


import static org.junit.Assert.*;

/**
 * Run all the JUunit tests.
 */
public class AllUnitTests {
       // private BankAccount bankAccount ;
}
